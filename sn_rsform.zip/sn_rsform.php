<?php
defined('_JEXEC') or die('Restricted access');

jimport('sncore.include');

class plgSystemSn_rsform extends JPlugin
{
	var $_products = array();
	
	function __construct(&$subject,$config)
	{
		parent::__construct($subject,$config);

		SNGlobal::loadLanguage('plg_system_sn_rsform',JPATH_ADMINISTRATOR);
		$this->newComponents = array(8621, 8622, 8623, 8624);
	}
	
	function canRun()
	{
		$helper = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_rsform'.DS.'helpers'.DS.'rsform.php';
		if(file_exists($helper) && !class_exists('RSFormProHelper'))
		{
			require_once($helper);
			RSFormProHelper::readConfig();
		}
		 
	    return (class_exists('RSFormProHelper') && class_exists('SNGlobal')) ? TRUE : FALSE;
	}
	
	/*
	 * Event Triggered Functions
	 */
	function rsfp_bk_onInit()
	{

	}

	function getLogoUrl()
    {
        return JUri::root(true) .'/plugins/system/sn_rsform/sn-logo.png';
    }

	/*
	 * Tabs(Menus) In Rsform Console
	 */
	function rsfp_bk_onAfterShowComponents()
	{
		if (!$this->canRun()) 
        {
            return;
        }
        $formId = $this->getRsformId();

		$link1 = "displayTemplate('8621')";
		$link2 = "displayTemplate('8622')";
		$link3 = "displayTemplate('8623')";
		$link4 = "displayTemplate('8624')";

		if($components = RSFormProHelper::componentExists($formId,8621))
		{
            $link1 = "displayTemplate('8621', '".$components[0]."')";
        }
		if($components = RSFormProHelper::componentExists($formId,8622))
        {
            $link2 = "displayTemplate('8622', '".$components[0]."')";
        }
		if($components = RSFormProHelper::componentExists($formId,8623))
        {
            $link3 = "displayTemplate('8623', '".$components[0]."')";
        }
        if($components = RSFormProHelper::componentExists($formId,8624))
        {
            $link4 = "displayTemplate('8624', '".$components[0]."')";
        }

		?>
		<li class="rsform_navtitle"><?php echo JText::_('SN_RSFORM_PAYMENT_TITLE'); ?></li>
        <li>
            <a href="javascript: void(0);" onclick="<?php echo $link1;?>;return false;" id="rsfpc8621">
                <span class="rsficon rsficon-sn-8621" style="background: url(<?php echo $this->getLogoUrl(); ?>) no-repeat 97% center;background-size: 18px 18px;"></span>
                <span class="inner-text"><?php echo JText::_('SN_RSFORM_SPRODUCT'); ?></span>
            </a>
        </li>
        <li>
            <a href="javascript: void(0);" onclick="<?php echo $link2;?>;return false;" id="rsfpc8622">
                <span class="rsficon rsficon-sn-8622" style="background: url(<?php echo $this->getLogoUrl(); ?>) no-repeat 97% center;background-size: 18px 18px;"></span>
                <span class="inner-text"><?php echo JText::_('SN_RSFORM_MPRODUCT'); ?></span>
            </a>
        </li>
        <li>
            <a href="javascript: void(0);" onclick="<?php echo $link3;?>;return false;" id="rsfpc8623">
                <span class="rsficon rsficon-sn-8623" style="background: url(<?php echo $this->getLogoUrl(); ?>) no-repeat 97% center;background-size: 18px 18px;"></span>
                <span class="inner-text"><?php echo JText::_('SN_RSFORM_TOTAL'); ?></span>
            </a>
        </li>
        <li>
            <a href="javascript: void(0);" onclick="<?php echo $link4;?>;return false;" id="rsfpc8624">
                <span class="rsficon rsficon-sn-8624" style="background: url(<?php echo $this->getLogoUrl(); ?>) no-repeat 97% center;background-size: 18px 18px;"></span>
                <span class="inner-text"><?php echo JText::_('SN_RSFORM_DONATION'); ?></span>
            </a>
        </li>
		<?php
	}
	
	/*
	 * Preview in backend forms field
	 */
	function rsfp_bk_onAfterCreateComponentPreview($args = array())
	{
		if(!$this->canRun())
        {
            return;
        }

		switch ($args['ComponentTypeName'])
		{
			case 'snrsformSingleProduct':
				$args['out'] = '<td>'.$args['data']['CAPTION'].'</td>';
				$args['out'].= '<td>'.$this->getSingleProductView($args,'backend').'</td>';
			break;
			case 'snrsformMultipleProducts':
				$args['out'] = '<td>'.$args['data']['CAPTION'].'</td>';
				$args['out'].= '<td>'.$this->getMultipleProductView($args,'backend').'</td>';
			break;
			case 'snrsformTotal':
				$args['out'] = '<td>'.$args['data']['CAPTION'].'</td>';
				$args['out'].= '<td>'.$this->getTotalPricesView($args,'backend').'</td>';
			break;
            case 'snrsformDonationProduct':
                $args['out'] = '<td>'.$args['data']['CAPTION'].'</td>';
                $args['out'].= '<td>'.$this->getDonationProductView($args,'backend').'</td>';
            break;
		}
	}

    /**
     * Frontend View
     */
	function rsfp_bk_onAfterCreateFrontComponentBody($args)
	{
		if (!$this->canRun()) 
        {
            return;
        }

		switch($args['r']['ComponentTypeId'])
		{
			case 8621:
				$args['out'] = $this->getSingleProductView($args,'frontend');
			break;
			case 8622:
				$args['out'] = $this->getMultipleProductView($args,'frontend');
			break;
			case 8623:
				$args['out'] = $this->getTotalPricesView($args,'frontend');
			break;
            case 8624:
                $args['out'] = $this->getDonationProductView($args,'frontend');
            break;
		}
	}

    /**
     * Get Total Prices View
     */
	function getTotalPricesView($args,$type)
    {
        $return = '';
        $data = $args['data'];

        if($type == 'backend')
        {
            $return .= '0';
        }
        elseif($type == 'frontend')
        {
            $return .= '<span id="snrsform-total-prices-preview-'.$this->getRsformId().'">0</span> ';
            $return .= '<span id="snrsform-total-prices-currency-'.$this->getRsformId().'">'.$this->getCurrency().'</span>';
            $return .= '<input type="hidden" id="snrsform-total-prices-'.$this->getRsformId().'" value="0" name="form['.$data['NAME'].']" />';
        }

        return $return;
    }

    /**
     * Create Donation Product View
     */
	function getDonationProductView($args,$type)
    {
        $data = $args['data'];
        $formId = $this->getRsformId();

        $return= "";
        $return .= '<input type="text" ';
        $return .= 'id="snrsform-donation-product-'.$formId.'" ';
        $return .= 'name="form['.$data['NAME'].']" ';
        $return .= (is_numeric($data['SIZE']) && $data['SIZE'] > 0) ? 'style="width: '.$data['SIZE'].'px !important;" ' : '';
        $return .= 'value="'.((is_numeric($data['DEFAULTVALUE']) && $data['DEFAULTVALUE']) ? $data['DEFAULTVALUE'] : '').'" ';
        $return .= 'onkeyup="SNRsformSetSeparator'.$formId.'(\'snrsform-donation-product-'.$formId.'\',\',\');SNModifyTotalPrice'.$formId.'();" ';
        $return .= !empty($data['ADDITIONALATTRIBUTES']) ? $data['ADDITIONALATTRIBUTES'] : '';
        $return .= '/>';

        return $return;
    }

    /**
     * Before Form Display In Frontend
     */
	function rsfp_f_onBeforeFormDisplay($args)
	{
		if(!$this->canRun())
        {
            return;
        }

        $formId = $this->getRsformId();

		$singleProduct = RSFormProHelper::componentExists($args['formId'],8621);
		$multipleProduct = RSFormProHelper::componentExists($args['formId'],8622);
		$donationProduct = RSFormProHelper::componentExists($args['formId'],8624);
		$total = RSFormProHelper::componentExists($args['formId'],8623);
		
		$singleProductArgs = RSFormProHelper::getComponentProperties($singleProduct);
		$multipleProductArgs = RSFormProHelper::getComponentProperties($multipleProduct);
        $donationProductArgs = RSFormProHelper::getComponentProperties($donationProduct);
		$totalArgs = RSFormProHelper::getComponentProperties($total);

        $singleProductArgs = !empty($singleProductArgs) ? $singleProductArgs[$singleProduct[0]] : '';
        $multipleProductArgs = !empty($multipleProductArgs) ? $multipleProductArgs[$multipleProduct[0]] : '';
        $donationProductArgs = !empty($donationProductArgs) ? $donationProductArgs[$donationProduct[0]] : '';
        $totalArgs = !empty($totalArgs) ? $totalArgs[$total[0]] : '';
		
		$return = '';
		
		if (!empty($singleProductArgs) || !empty($multipleProductArgs) || !empty($donationProductArgs))
		{
			$return .='<script class="snrsform-script" type="text/javascript">';
			$return .='
			    function removeSeperator(num)
                {
                    num += \'\';
                    return Number(num.replace(/[^0-9\.]+/g,""));
                }
                function modifyNumberBySeperator(num,sep)
                {
                    num = removeSeperator(num);
                    var parts = num.toString().split(".");
                    var ret = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, sep) + (parts[1] ? "." + parts[1] : "");
                    return (ret == 0 ? \'\' : ret);
                }
                function SNRsformSetSeparator'.$formId.'(id,sep)
                {
                    var price = document.getElementById("snrsform-donation-product-'.$formId.'").value;
                    price = modifyNumberBySeperator(price,sep);
                    document.getElementById("snrsform-donation-product-'.$formId.'").value = price;
                }
                function SNModifyTotalPrice'.$formId.'()
                {
                    var price = 0;
                    ';
                    if(!empty($singleProductArgs))
                    {
                        $return .= 'price += +document.getElementById("snrsform-single-product-'.$formId.'").value;';
                    }

                    if(!empty($multipleProductArgs))
                    {
                        if($multipleProductArgs['VIEW_TYPE']== 'DROPDOWN' && $multipleProductArgs['MULTIPLE'] == 'YES')
                        {
                            $return .= "var elemd = document.getElementById('snrsform-multiple-product-se-".$formId."');
                                        for(i=0; i < elemd.options.length; i++)
                                        {
                                            if(elemd.options[i].selected == true) 
                                            {
                                                price += +parseFloat(elemd.options[i].getAttribute('price')); 
                                            }
                                        }
                                        ";
                        }
                        elseif($multipleProductArgs['VIEW_TYPE']== 'DROPDOWN' && $multipleProductArgs['MULTIPLE'] == 'NO')
                        {
                            $return .= "var element = document.getElementById('snrsform-multiple-product-se-".$formId."');";
                            $return .= "price += +parseFloat(element.options[element.selectedIndex].getAttribute('price'));";
                        }
                        elseif($multipleProductArgs['VIEW_TYPE'] == 'CHECKBOX' || $multipleProductArgs['VIEW_TYPE'] == 'RADIOGROUP')
                        {
                            $return .=
                                    "var elemc = document.getElementsByClassName('snrsform-multiple-product-cb-".$formId."');
                                    for(i=0; i < elemc.length; i++)
                                    {
                                        if(elemc[i].checked == true ) 
                                        {
                                            price += +parseFloat(elemc[i].getAttribute('price'));
                                        }
                                    }
                                    ";
                        }
                    }

                    if(!empty($donationProductArgs))
                    {
                        $return .= 'var donationPrice = document.getElementById("snrsform-donation-product-'.$formId.'").value;';
                        $return .= 'price += removeSeperator(donationPrice);';
                    }

                    if (!empty($totalArgs))
                    {
                        $return .= 'price = modifyNumberBySeperator(price,",");';
                        $return .= 'document.getElementById(\'snrsform-total-prices-preview-'.$formId.'\').innerHTML = price;';
                        $return .= 'document.getElementById(\'snrsform-total-prices-'.$formId.'\').value = price;';
                    }
		$return .='}</script>';
		$return .='<script type="text/javascript">SNModifyTotalPrice'.$formId.'();</script>';
		
		}
		
		$args['formLayout'] .= $return;
	}
	
	function rsfp_f_onBeforeStoreSubmissions($args)
	{
		if (!$this->canRun()) 
        {
            return;
        }

		if (RSFormProHelper::componentExists($args['formId'],$this->newComponents))
        {
            $args['post']['_STATUS'] = '0';
        }
	}

    /**
     * Redirect To Bank
     */
	function rsfp_f_onAfterFormProcess($args)
	{
		if (!$this->canRun()) 
        {
            return;
        }

		$submissionId = $args['SubmissionId'];
		$formId = $args['formId'];

		if(RSFormProHelper::componentExists($formId,$this->newComponents))
		{
            $submissions = SNGlobal::selectByQuery("SELECT * FROM `#__rsform_submission_values` WHERE `SubmissionId`='".SNGlobal::escape($submissionId)."' AND `formId`='".SNGlobal::escape($formId)."'");
            $submissions = SNGlobal::indexArray($submissions,'FieldName');
            $orderItems = array();
            $amount = 0;

            $single = RSFormProHelper::componentExists($args['formId'], 8621);
            $multiple = RSFormProHelper::componentExists($args['formId'], 8622);
            $total = RSFormProHelper::componentExists($args['formId'], 8623);
            $donation = RSFormProHelper::componentExists($args['formId'], 8624);

            $allComponents = array();
            if($donation)
            {
                $allComponents = array_merge($allComponents, $donation);
            }
            if($single)
            {
                $allComponents = array_merge($allComponents, $single);
            }
            if($multiple)
            {
                $allComponents = array_merge($allComponents, $multiple);
            }
            if($total)
            {
                $allComponents = array_merge($allComponents, $total);
            }
            $properties = RSFormProHelper::getComponentProperties($allComponents);

            if($single)
            {
                $data = !empty($properties[$single[0]]) ? $properties[$single[0]] : array();

                if(!empty($data))
                {
                    $price = (int)$data['PRICE'];
                    $name = !empty($data['CAPTION']) ? $data['CAPTION'] : '';

                    $orderItems[] = array(
                        'name' => $name,
                        'count' => 1,
                        'amount' => $price,
                    );
                    $amount += $price;

                    $value = $name.' - '.$price;
                    $this->_updateSubmissionFieldValue($submissions['SingleProduct']['SubmissionValueId'],$value);
                }
            }

            if($multiple)
            {
                foreach($multiple as $componentId)
                {
                    $data = !empty($properties[$componentId]) ? $properties[$componentId] : array();
                    $subValue = $this->_getSubmissionValue($args['SubmissionId'],$data['NAME']);

                    if($subValue != '' && !empty($data))
                    {
                        $value = '';

                        $items = $subValue;
                        $items = str_replace("\r", "", $items);
                        $items = explode("\n", $items);

                        $allItems = $this->_getAllMultipleProductItems($data['ITEMS']);

                        foreach($items as $item)
                        {
                            if(isset($allItems[$item]))
                            {
                                $price = (int)$allItems[$item]['price'];
                                $name = $allItems[$item]['name'];

                                $orderItems[] = array(
                                    'name' => $name,
                                    'count' => 1,
                                    'amount' => $price,
                                );
                                $amount += $price;

                                $value .= $name.' - '.$this->modifyPrice($price);
                            }
                        }

                        $this->_updateSubmissionFieldValue($submissions['MultipleProducts']['SubmissionValueId'],$value);
                    }
                }
            }

            if($donation)
            {
                $data = !empty($properties[$donation[0]]) ? $properties[$donation[0]] : array();
                $subValue = $this->_getSubmissionValue($args['SubmissionId'],$data['NAME']);

                if(!empty($subValue) && !empty($data))
                {
                    $price = str_replace(',','',$subValue);

                    $name = !empty($data['CAPTION']) ? $data['CAPTION'] : '';

                    $orderItems[] = array(
                        'name' => $name,
                        'count' => 1,
                        'amount' => $price,
                    );
                    $amount += $price;

                    $value = $name.' - '.$this->modifyPrice($price);
                    $this->_updateSubmissionFieldValue($submissions['DonationProduct']['SubmissionValueId'],$value);
                }
            }

            if($total)
            {
                $data = !empty($properties[$total[0]]) ? $properties[$total[0]] : array();
                $subValue = $this->_getSubmissionValue($args['SubmissionId'],$data['NAME']);

                if($subValue != '' && !empty($data))
                {
                    $price = str_replace(',','',$subValue);

                    $value = $this->modifyPrice($price);
                    $this->_updateSubmissionFieldValue($submissions['SumPrices']['SubmissionValueId'],$value);
                }
            }

			if($amount > 0)
			{
			    $subInfo = SNGlobal::selectByQuery("SELECT * FROM `#__rsform_submissions` WHERE `SubmissionId` = '".$submissionId."'",2);
                $code = substr(md5($subInfo['SubmissionId'].$subInfo['DateSubmitted'].$subInfo['FormId']),10,10);

                $backUrl = JURI::root().'index.php?option=com_rsform&formId='.$formId.'&task=plugin&plugin_task=snrsform.verify&code='.$code;
                $cancelUrl = JRoute::_('index.php?option=com_rsform&view=rsform&formId='.$formId);

                $pin = $this->params->get('sn_pin');
                $currency = $this->params->get('sn_currency');
                $sendPayerInfo = $this->params->get('sn_send_payer_info');

                $amount = SNApi::modifyPrice($amount,$currency);
                $orderId = $submissionId;

                $data = array(
                    'pin'=> $pin,
                    'price'=> $amount,
                    'callback'=> $backUrl,
                    'order_id'=> $orderId,
                    'description'=> '',
                    'mobile'=> '',
                    'rsform' => array(
                        'submissionId' => $subInfo['SubmissionId'],
                        'formId' => $formId,
                        'code' => $code,
                    )
                );

                list($status,$msg,$resultData) = SNApi::request($data,$sendPayerInfo,'rsform');

                if($status == true)
                {
                    $data['bank_callback_details'] = $resultData['bank_callback_details'];
                    $data['au'] = $resultData['au'];

                    SNApi::clearData();
                    SNApi::setData($data);

                    $html = '<div class="sn-rsform-go-to-bank" style="text-align: center; direction: rtl;">'.JText::_('SN_CONNECTING_TO_PORTAL').'</div>';
                    $html .= SNGlobal::postData($resultData['form_details']['action'],$resultData['form_details']['fields'],100);
                    echo $html;
                    die();
                }

                $app = JFactory::getApplication();
                $app->redirect($cancelUrl,'<h5>'.$msg.'</h5>','error');
                return;
			}
		}
	}

    /**
     * Unescaped Fields in Submissions [backend]
     */
	function rsfp_b_onManageSubmissionsCreateUnescapedFields($fields)
    {
        $fields['fields'][] = 'SingleProduct';
        $fields['fields'][] = 'MultipleProducts';
        $fields['fields'][] = 'DonationProduct';
        $fields['fields'][] = 'SumPrices';

        return $fields;
    }

    /* Mange Submissions */
    function rsfp_b_onManageSubmissions($submissions)
    {

    }

    /**
     * Verify
     */
    function rsfp_f_snVerify()
	{
        $au = SNGlobal::getVar('au','','none','request');
        $orderId = SNGlobal::getVar('order_id','','none','request');
        $sessionData = SNApi::getData();
        $verified = false;

        if(!empty($au) && !empty($orderId) && !empty($sessionData) && $sessionData['order_id'] == $orderId)
        {
            $formId = $sessionData['rsform']['formId'];
            $rsformCode = $sessionData['rsform']['code'];
            $submissionId = $sessionData['rsform']['submissionId'];

            $sInfo = SNGlobal::selectByQuery("SELECT * FROM `#__rsform_submissions` WHERE `SubmissionId` = '".SNGlobal::escape($submissionId)."'",2);
            $code = substr(md5($sInfo['SubmissionId'].$sInfo['DateSubmitted'].$sInfo['FormId']),10,10);

            if($code == $rsformCode)
            {
                $bankData = array();
                foreach (!empty($sessionData['bank_callback_details']['params']) ? $sessionData['bank_callback_details']['params'] : array() as $bankParam)
                {
                    $bankData[$bankParam] = !empty($_REQUEST[$bankParam]) ? $_REQUEST[$bankParam] : '';
                }

                $data = array (
                    'pin' => $sessionData['pin'],
                    'price' => $sessionData['price'],
                    'order_id' => $sessionData['order_id'],
                    'au' => $au,
                    'bank_return' => $bankData,
                );

                list($status,$msg,$resultData) = SNApi::verify($data,'rsform');
                
                if($status == true)
                {
                    $verified = true;
                    $bankAu = !empty($resultData['bank_au']) ? $resultData['bank_au'] : $au;

                    $query = "UPDATE `#__rsform_submission_values` SET `FieldValue`='1' WHERE `FieldName`='_STATUS' AND `FormId`='".SNGlobal::escape($formId)."' AND `SubmissionId`='".SNGlobal::escape($submissionId)."'";
                    SNGlobal::update($query);
                }
            }
        }

        if($verified)
        {
            $message = JText::_('SN_PAID_TRANSACTION');
            $message = str_replace('{REF}',$bankAu,$message);
        }
        else
        {
            $message = JText::_('SN_UNPAID_TRANSACTION');
        }

        $session = JFactory::getSession();
        $formParams = $session->get('com_rsform.formparams.formId'.$formId);
        if($formParams && $formParams->redirectUrl)
        {
            // Mark form as processed
            $formParams->formProcessed = true;

            $formParams->thankYouMessage = base64_encode($message.'<br/>'.base64_decode($formParams->thankYouMessage));

            // Store new session data
            $session->set('com_rsform.formparams.formId'.$formId, $formParams);

            // Redirect
            SNGlobal::redirect($formParams->redirectUrl);
        }
        else
        {
            $app = JFactory::getApplication();
            $app->enqueueMessage($message,'error');
        }
	}

    /**
     * Switch Tasks
     */
	function rsfp_f_onSwitchTasks()
    {
        $pluginTask = JRequest::getVar('plugin_task');
        switch($pluginTask)
        {
            case 'snrsform.verify':
                $this->rsfp_f_snVerify();
            break;
        }
    }

	function getComponentName($componentId)
	{
		$componentId = (int) $componentId;
		
		$db = JFactory::getDBO();
		$db->setQuery("SELECT PropertyValue FROM #__rsform_properties WHERE ComponentId='".$componentId."' AND PropertyName='NAME'");
		return $db->loadResult();
	}
	
	function getComponentId($name, $formId)
	{
		$formId = (int) $formId;
		
		$db = JFactory::getDBO();
		$db->setQuery("SELECT p.ComponentId FROM #__rsform_properties p LEFT JOIN #__rsform_components c ON (p.ComponentId=c.ComponentId) WHERE p.PropertyValue='".$db->getEscaped($name)."' AND p.PropertyName='NAME' AND c.FormId='".$formId."'");
		
		return $db->loadResult();
	}
	
	function getSubmissionValue($submissionId, $componentId)
	{
		$name = $this->getComponentName($componentId);
		
		$db = JFactory::getDBO();
		$db->setQuery("SELECT FieldValue FROM #__rsform_submission_values WHERE SubmissionId='".(int) $submissionId."' AND FieldName='".$db->getEscaped($name)."'");
		return $db->loadResult();
	}

    /**
     * Get Single Product View
     */
	function getSingleProductView($args,$type)
	{
		$return = '';
        $data = $args['data'];
        $price = (int)($data['PRICE']);
        $modifyPrice = $this->modifyPrice($price);

        if($data['SHOW'] != 'NO')
        {
            $return .= $modifyPrice;
        }

        if($type == 'frontend')
        {
            $return .= '<input type="hidden" ';
            $return .= 'name="form['.$data['NAME'].']" ';
            $return .= 'value="'.$price.'" ';
            $return .= 'id="snrsform-single-product-'.$this->getRsformId().'" ';
            $return .= '/>';
        }
        
		return $return;
	}

	function modifyPrice($price)
    {

        return number_format($price).' '.$this->getCurrency();
    }

    function getCurrency()
    {
        $currency = $this->params->get('sn_currency');
        $currency = JText::_($currency == 1 ? 'SN_FIELD_CURRENCY_RIAL' : 'SN_FIELD_CURRENCY_TOMAN');
        return $currency;
    }

    /**
     * Get Multiple Product View
     */
	function getMultipleProductView($args,$type)
	{
		$return = '';
		$data = $args['data'];
		$viewType = $data['VIEW_TYPE'];
		
        $items = $this->_getAllMultipleProductItems($data['ITEMS']);

		if($viewType == 'DROPDOWN')
        {
            $return .= '<select ';
            $return .= 'name="form['.$data['NAME'].']'.($data['MULTIPLE'] == 'YES' ? '[]' : '').'" ';
            $return .= $data['MULTIPLE'] == 'YES' ? 'multiple="multiple" ' : '';
            $return .= 'id="snrsform-multiple-product-se-'.$this->getRsformId().'" ';
            $return .= !empty($data['SIZE']) && $data['SIZE'] > 0 ? 'style="width:'.$data['SIZE'].'px !important;" ' : '';
            $return .= 'onchange="SNModifyTotalPrice'.$this->getRsformId().'();" ';
            $return .= !empty($data['ADDITIONALATTRIBUTES']) ? $data['ADDITIONALATTRIBUTES'] : '';
            $return .= '>';
        }

		if(!empty($items))
		{
			foreach($items as $itemKey => $item)
			{
			    $optionValue = '';
			    $optionValue .= (isset($data['SHOW_MP_TITLES']) && $data['SHOW_MP_TITLES'] == 'YES') ? $item['name'] . ' - ' : '';
                $optionValue .=  $this->modifyPrice($item['price']);

				if($viewType == 'DROPDOWN')
				{
				    $return .= '<option value="'.RSFormProHelper::htmlEscape($itemKey).'" price="'.$item['price'].'">';
                    $return .= RSFormProHelper::htmlEscape($optionValue);
                    $return .= '</option>';
				}
				elseif($viewType == 'CHECKBOX' || $viewType == 'RADIOGROUP')
				{
				    $return .= '<input ';
				    $return .= 'type="'.($viewType == 'CHECKBOX' ? 'checkbox' : 'radio').'" ';
                    $return .= 'name="form['.$data['NAME'].'][]" ';
                    $return .= 'value="'.RSFormProHelper::htmlEscape($itemKey).'" ';
                    $return .= 'class="snrsform-multiple-product-cb-'.$this->getRsformId().'" ';
                    $return .= 'id="snrsform-multiple-product-cb-'.$this->getRsformId().'-'.$itemKey.'" ';
                    $return .= 'onchange="SNModifyTotalPrice'.$this->getRsformId().'();" ';
                    $return .= 'price="'.$item['price'].'" ';
                    $return .= !empty($data['ADDITIONALATTRIBUTES']) ? $data['ADDITIONALATTRIBUTES'] : '';
                    $return .= '/>';

                    $return .= '<label for="snrsform-multiple-product-cb-'.$this->getRsformId().'-'.$itemKey.'">';
                    $return .= RSFormProHelper::htmlEscape($optionValue);
                    $return .= '</label>';

                    if($args['data']['FLOW']=='VERTICAL')
                    {
                        $return .= '<br/>';
                    }
				}
			}
		}

		if($viewType == 'DROPDOWN')
        {
            $return .= '</select>';
        }

		return $return;
	}
	
	function getRsformId()
	{
		$formId = JRequest::getInt('formId');
		if(empty($formId))
		{
			$post   = JRequest::getVar('form');
			$formId = (int) @$post['formId'];
		}
		return $formId;
	}

    function _getSubmissionValue($submissionId,$componentId)
    {
        if (is_numeric($componentId))
        {
            $name = $this->_getComponentName($componentId);
        }
        else
        {
            $name = $componentId;
        }

        $db = JFactory::getDbo();
        $db->setQuery("SELECT FieldValue FROM #__rsform_submission_values WHERE SubmissionId='".(int) $submissionId."' AND FieldName='".$db->escape($name)."'");
        return $db->loadResult();
    }

    function _getAllMultipleProductItems($items)
    {
        if(empty($items))
        {
            return array();
        }

        $items = str_replace("\r", "", $items);
        $items = explode("\n", $items);

        if(empty($items))
        {
            return array();
        }

        $return = array();
        $counter = 1;
        foreach($items as $item)
        {
            if(empty($item))
            {
                continue;
            }

            $buf = explode('|',$item);
            if(count($buf) == 2)
            {
                $return[$counter] = array(
                    'name' => trim($buf[0]),
                    'price' => trim((int)$buf[1]),
                );
                $counter++;
            }
        }
        
        return $return;
    }

    function _createSubmissionFieldValueRow($value)
    {
        return '<div class="sn-rsf-row" style="white-space: nowrap;">'.$value.'</div>';
    }

    function _updateSubmissionFieldValue($submissionId,$value)
    {
        return SNGlobal::update("UPDATE `#__rsform_submission_values` SET `FieldValue`='".SNGlobal::escape($value)."' WHERE `SubmissionValueId`='".SNGlobal::escape($submissionId)."'");
    }
}