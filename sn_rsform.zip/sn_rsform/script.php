<?php
defined('_JEXEC') or die('Restricted access');

jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');

if(!defined('DS'))
{
    define('DS',DIRECTORY_SEPARATOR);
}

class plgSystemSn_rsformInstallerScript
{
    function preflight($type,$parent)
    {
        if(!JFolder::exists(JPATH_ADMINISTRATOR .DS. 'components' .DS. 'com_rsform'))
        {
            Jerror::raiseWarning(null,'لطفا ابتدا افزونه آراس فرم را نصب نمایید.');
            return false;
        }
    }

    function postflight($type,$parent)
    {
        /* Enable Plugin */
        $database = JFactory::getDBO();
        $query = "UPDATE `#__extensions` SET `enabled` = 1 WHERE `element` = 'sn_rsform'";
        $database->setQuery($query);
        $database->query();

        /* Move Libraries Files */
        $from = JPATH_ROOT .DS. 'plugins' .DS. 'system' .DS. 'sn_rsform' .DS. 'libraries' .DS;
        $to = JPATH_ROOT .DS. 'libraries' .DS;
        JFolder::copy($from,$to,'',true);

        if(JFolder::exists($from))
        {
            JFolder::delete($from);
        }

        /* create fields */
        jimport('sncore.include');
        $mpDefaultValue = 'محصول یک|10000\r\nمحصول دو|20000\r\nمحصول سه|30000\r\nمحصول چهار|40000\r\n';

        $queries = "
            INSERT IGNORE INTO `#__rsform_component_types` (`ComponentTypeId`, `ComponentTypeName`) VALUES (8621, 'snrsformSingleProduct');
            INSERT IGNORE INTO `#__rsform_component_types` (`ComponentTypeId`, `ComponentTypeName`) VALUES (8622, 'snrsformMultipleProducts');
            INSERT IGNORE INTO `#__rsform_component_types` (`ComponentTypeId`, `ComponentTypeName`) VALUES (8623, 'snrsformTotal');
            INSERT IGNORE INTO `#__rsform_component_types` (`ComponentTypeId`, `ComponentTypeName`) VALUES (8624, 'snrsformDonationProduct');
            
            DELETE FROM `#__rsform_component_type_fields` WHERE `ComponentTypeId` IN (8621, 8622, 8623, 8624);
            
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8621, 'COMPONENTTYPE', 'hidden', '8621', 0);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8621, 'NAME', 'hiddenparam', 'SingleProduct', 0);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8621, 'CAPTION', 'textbox', '', 1);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8621, 'DESCRIPTION', 'textarea', '', 2);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8621, 'SHOW', 'select', 'YES\r\nNO', 3);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8621, 'PRICE', 'textbox', '', 4);
            
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8622, 'COMPONENTTYPE', 'hidden', '8622', 0);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8622, 'NAME', 'hiddenparam', 'MultipleProducts', 0);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8622, 'CAPTION', 'textbox', '', 1);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8622, 'DESCRIPTION', 'textarea', '', 2);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8622, 'SIZE', 'textbox', '', 3);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8622, 'MULTIPLE', 'select', 'NO\r\nYES', 4);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8622, 'ITEMS', 'textarea', '".$mpDefaultValue."', 5);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8622, 'نمایش عنوان ها', 'select', 'YES\r\nNO', 6);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8622, 'REQUIRED', 'select', 'NO\r\nYES', 7);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8622, 'ADDITIONALATTRIBUTES', 'textarea', '', 8);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8622, 'VALIDATIONMESSAGE', 'textarea', 'INVALIDINPUT', 9);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8622, 'VIEW_TYPE', 'select', 'DROPDOWN\r\nCHECKBOX\r\nRADIOGROUP', 10);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8622, 'FLOW', 'select', 'HORIZONTAL\r\nVERTICAL', 11);
            
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8623, 'COMPONENTTYPE', 'hidden', '8623', 0);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8623, 'NAME', 'hiddenparam', 'SumPrices', 1);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8623, 'CAPTION', 'textbox', '', 2);
            
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8624, 'COMPONENTTYPE', 'hidden', '8624', 0);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8624, 'NAME', 'hiddenparam', 'DonationProduct', 1);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8624, 'CAPTION', 'textbox', '', 2);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8624, 'DESCRIPTION', 'textarea', '', 3);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8624, 'REQUIRED', 'select', 'NO\r\nYES', 4);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8624, 'SIZE', 'textbox', '', 5);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8624, 'VALIDATIONMESSAGE', 'textarea', 'INVALIDINPUT', 6);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8624, 'ADDITIONALATTRIBUTES', 'textarea', '', 7);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8624, 'DEFAULTVALUE', 'textbox', '', 8);
            INSERT IGNORE INTO `#__rsform_component_type_fields` (`ComponentTypeId`, `FieldName`, `FieldType`, `FieldValues`, `Ordering`) VALUES (8624, 'VALIDATIONEXTRA', 'textbox', '', 9); 
        ";

        $queries = explode(';',$queries);
        foreach($queries as $key => $query)
        {
            $query = trim($query);
            if(!empty($query))
            {
                SNGlobal::insert($query);
            }
        }

        return TRUE;
    }

    function uninstall($parent)
    {
        jimport('sncore.include');
        $queries = "
            DELETE FROM `#__rsform_component_type_fields` WHERE `ComponentTypeId` IN(8621,8622,8623,8624);
            DELETE FROM `#__rsform_component_types` WHERE `ComponentTypeId` IN(8621,8622,8623,8624);
        ";

        $queries = explode(';',$queries);
        foreach ($queries as $key => $query)
        {
            $query = trim($query);
            if(!empty($query))
            {
                SNGlobal::delete($query);
            }
        }

        return TRUE;
    }
}